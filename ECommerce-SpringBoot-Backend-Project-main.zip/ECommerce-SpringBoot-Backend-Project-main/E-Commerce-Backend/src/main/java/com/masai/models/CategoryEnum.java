package com.masai.models;


public enum CategoryEnum {
	
	BOOKS,FASHION,ELECTRONICS,FURNITURE,GROCERIES

}
