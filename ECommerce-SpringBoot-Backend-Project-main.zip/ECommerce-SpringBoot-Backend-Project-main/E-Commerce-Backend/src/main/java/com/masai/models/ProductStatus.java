package com.masai.models;

public enum ProductStatus {
	
	AVAILABLE,OUTOFSTOCK
	
	
}
